package net.ulatina.quiz.entidades;

public enum TipoCasual {
    JUVENIL, ESCOLAR, FORMAL
}
