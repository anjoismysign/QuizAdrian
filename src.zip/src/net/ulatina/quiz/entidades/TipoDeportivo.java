package net.ulatina.quiz.entidades;

public enum TipoDeportivo {
    FUTBOL, VOLEIBOL, BASQUETBOL, ATLETISMO
}
